# Automotive Virtual Showroom Market Dataset
Structured dataset based on publicly available information from the Automotive Virtual Showroom Market page on NextMSC.

## Files Included
- metadata.json
- summary.txt
- segments.csv
- companies.csv
- toc.txt

## License
MIT License
